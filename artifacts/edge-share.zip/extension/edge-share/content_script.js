"use strict";

const SOURCE_PAGE = "browser-connection:page";
const SOURCE_CONTENT = "browser-connection:content";
const SOURCE_RECORDER = "browser-connection:recorder";

injectProvider();
installRecorder();

window.addEventListener("message", (event) => {
  if (event.source !== window || event.origin !== window.location.origin) {
    return;
  }
  const message = event.data;
  if (!message || message.source !== SOURCE_PAGE || !message.id) {
    if (message && message.source === SOURCE_RECORDER && message.kind === "navigate") {
      recordAction({ kind: "navigate" });
    }
    return;
  }

  chrome.runtime.sendMessage(
    {
      type: "platform_request",
      id: message.id,
      method: message.method,
      params: message.params || {},
      origin: window.location.origin,
      href: window.location.href,
      title: document.title || ""
    },
    (response) => {
      const runtimeError = chrome.runtime.lastError;
      if (runtimeError) {
        postResponse(message.id, false, null, runtimeError.message);
        return;
      }
      if (!response || response.ok !== true) {
        postResponse(
          message.id,
          false,
          null,
          (response && response.error) || "Extension request failed"
        );
        return;
      }
      postResponse(message.id, true, response.result, "");
    }
  );
});

function injectProvider() {
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("provider.js");
  script.async = false;
  script.onload = () => script.remove();
  (document.documentElement || document.head || document.body).appendChild(script);
}

function postResponse(id, ok, result, error) {
  window.postMessage(
    {
      source: SOURCE_CONTENT,
      id,
      ok,
      result,
      error
    },
    window.location.origin
  );
}

function installRecorder() {
  const pendingInputs = new Map();

  document.addEventListener("click", (event) => {
    const target = closestRecordableElement(event.target);
    if (!target) return;
    recordAction({
      kind: "click",
      selector: bestSelector(target),
      label: elementLabel(target),
      tag: target.tagName.toLowerCase()
    });
  }, true);

  document.addEventListener("input", (event) => {
    const target = closestRecordableElement(event.target);
    if (!target || !isEditable(target)) return;
    const selector = bestSelector(target);
    clearTimeout(pendingInputs.get(selector));
    pendingInputs.set(selector, setTimeout(() => {
      pendingInputs.delete(selector);
      recordFill(target);
    }, 350));
  }, true);

  document.addEventListener("change", (event) => {
    const target = closestRecordableElement(event.target);
    if (!target || !isEditable(target)) return;
    recordFill(target);
  }, true);

  document.addEventListener("keydown", (event) => {
    if (!shouldRecordKey(event)) return;
    const target = closestRecordableElement(event.target);
    recordAction({
      kind: "press",
      selector: target ? bestSelector(target) : "",
      key: keyName(event),
      label: target ? elementLabel(target) : "",
      tag: target ? target.tagName.toLowerCase() : ""
    });
  }, true);

  window.addEventListener("pageshow", () => {
    recordAction({ kind: "navigate" });
  });
}

function recordFill(element) {
  if (isSensitiveEditable(element)) return;
  const value = elementValue(element);
  recordAction({
    kind: "fill",
    selector: bestSelector(element),
    text: value,
    label: elementLabel(element),
    tag: element.tagName.toLowerCase()
  });
}

function recordAction(action) {
  if (!/^https?:\/\//i.test(location.href)) return;
  chrome.runtime.sendMessage({
    type: "recorder_action",
    action: {
      ...action,
      url: location.href,
      title: document.title || ""
    }
  }, () => {
    void chrome.runtime.lastError;
  });
}

function closestRecordableElement(node) {
  if (!node || node.nodeType !== Node.ELEMENT_NODE) {
    return null;
  }
  return node.closest("a,button,input,textarea,select,[role='button'],[contenteditable='true'],[data-testid],[data-test],[data-qa]");
}

function isEditable(element) {
  const tag = element.tagName.toLowerCase();
  return element.isContentEditable || tag === "input" || tag === "textarea" || tag === "select";
}

function isSensitiveEditable(element) {
  const haystack = [
    element.type,
    element.name,
    element.id,
    element.getAttribute("autocomplete"),
    element.getAttribute("aria-label"),
    element.getAttribute("placeholder")
  ].join(" ").toLowerCase();
  return /\b(password|passwd|token|secret|otp|2fa|mfa|code)\b/.test(haystack);
}

function elementValue(element) {
  if (element.isContentEditable) return element.innerText || "";
  if ("value" in element) return element.value || "";
  return "";
}

function shouldRecordKey(event) {
  if (event.isComposing) return false;
  if (event.ctrlKey || event.metaKey || event.altKey) return true;
  return [
    "Enter",
    "Escape",
    "Tab",
    "ArrowUp",
    "ArrowDown",
    "ArrowLeft",
    "ArrowRight",
    "Backspace",
    "Delete"
  ].includes(event.key);
}

function keyName(event) {
  const parts = [];
  if (event.ctrlKey) parts.push("Control");
  if (event.metaKey) parts.push("Meta");
  if (event.altKey) parts.push("Alt");
  if (event.shiftKey && event.key !== "Shift") parts.push("Shift");
  parts.push(event.key);
  return parts.join("+");
}

function bestSelector(element) {
  const direct = stableSelector(element);
  if (direct) return direct;
  const labelled = labelledSelector(element);
  if (labelled) return labelled;
  return cssPath(element);
}

function stableSelector(element) {
  for (const name of ["data-testid", "data-test", "data-qa", "data-cy"]) {
    const value = element.getAttribute(name);
    if (value) return `[${name}="${cssString(value)}"]`;
  }
  if (element.id) return `#${cssIdent(element.id)}`;
  if (element.getAttribute("name")) {
    return `${element.tagName.toLowerCase()}[name="${cssString(element.getAttribute("name"))}"]`;
  }
  return "";
}

function labelledSelector(element) {
  const label = element.getAttribute("aria-label") || element.getAttribute("placeholder") || element.getAttribute("title");
  if (!label) return "";
  return `${element.tagName.toLowerCase()}[${element.getAttribute("aria-label") ? "aria-label" : element.getAttribute("placeholder") ? "placeholder" : "title"}="${cssString(label)}"]`;
}

function cssPath(element) {
  const parts = [];
  let current = element;
  while (current && current.nodeType === Node.ELEMENT_NODE && parts.length < 5) {
    let part = current.tagName.toLowerCase();
    if (current.classList.length > 0) {
      part += `.${cssIdent(current.classList[0])}`;
    }
    const parent = current.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children).filter((child) => child.tagName === current.tagName);
      if (siblings.length > 1) {
        part += `:nth-of-type(${siblings.indexOf(current) + 1})`;
      }
    }
    parts.unshift(part);
    current = parent;
  }
  return parts.join(" > ");
}

function elementLabel(element) {
  return String(
    element.getAttribute("aria-label") ||
    element.getAttribute("alt") ||
    element.getAttribute("title") ||
    element.getAttribute("placeholder") ||
    element.innerText ||
    element.value ||
    ""
  ).replace(/\s+/g, " ").trim().slice(0, 300);
}

function cssIdent(value) {
  if (window.CSS && typeof CSS.escape === "function") {
    return CSS.escape(String(value));
  }
  return String(value).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
}

function cssString(value) {
  return String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}
